//
//  AddPlantViewController.swift
//  midpoint
//
//  Created by Amanda He on 12/1/22.
//

import UIKit

class AddPlantViewController: UIViewController {
    
    let headerLabel = UILabel()
    let nameTextView = UITextView()
    let scientificNameTextView = UITextView()
    let lastWateredTextView = UITextView()
    let saveButton = UIButton()
    
    weak var delegate: AddPlantDelegate?
    
    init(delegate: AddPlantDelegate) {
        self.delegate = delegate
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .white
        
        
        headerLabel.text = "Add Plant"
        headerLabel.font = .boldSystemFont(ofSize: 20)
        headerLabel.translatesAutoresizingMaskIntoConstraints = false
        headerLabel.font = .systemFont(ofSize: 20)
        view.addSubview(headerLabel)
        
        nameTextView.text = "Insert Plant Name"
        nameTextView.translatesAutoresizingMaskIntoConstraints = false
        nameTextView.clipsToBounds = true
        nameTextView.layer.cornerRadius = 5
        nameTextView.backgroundColor =  UIColor(red: 0.2, green: 0.2, blue: 0.2, alpha: 1)
        nameTextView.textColor =  .white
        nameTextView.font = .systemFont(ofSize: 16)
        view.addSubview(nameTextView)
        
        scientificNameTextView.text = "Insert Plant's Scientific Name"
        scientificNameTextView.translatesAutoresizingMaskIntoConstraints = false
        scientificNameTextView.clipsToBounds = true
        scientificNameTextView.layer.cornerRadius = 5
        scientificNameTextView.backgroundColor = UIColor(red: 0.4, green: 0.4, blue: 0.4, alpha: 1)
        scientificNameTextView.textColor =  .white
        scientificNameTextView.font = .systemFont(ofSize: 16)
        view.addSubview(scientificNameTextView)
        
        lastWateredTextView.text = "Last Watered: 123456ms ago"
        lastWateredTextView.translatesAutoresizingMaskIntoConstraints = false
        lastWateredTextView.clipsToBounds = true
        lastWateredTextView.layer.cornerRadius = 5
        lastWateredTextView.backgroundColor = UIColor(red: 0.6, green: 0.6, blue: 0.6, alpha: 1)
        lastWateredTextView.textColor =  .white
        lastWateredTextView.font = .systemFont(ofSize: 16)
        view.addSubview(lastWateredTextView)
        
        saveButton.setTitle("Save", for: .normal)
        saveButton.translatesAutoresizingMaskIntoConstraints = false
        saveButton.backgroundColor = UIColor(red: 0.1, green: 0.6, blue: 0.2, alpha: 1)
        saveButton.layer.cornerRadius = 12
        saveButton.addTarget(self, action: #selector(saveAction), for: .touchUpInside)
        view.addSubview(saveButton)

        // Do any additional setup after loading the view.
        setupConstraints()
    }
    
    @objc func saveAction() {
//        let id = Int(idTextField.text!)
        let name = nameTextView.text!
        let scientificName = scientificNameTextView.text!
        
        delegate?.addPlant(name: name, scientificName: scientificName)
        navigationController?.popViewController(animated: true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    func setupConstraints() {
        
        NSLayoutConstraint.activate([
            headerLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            headerLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
        
        NSLayoutConstraint.activate([
            nameTextView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            nameTextView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 60),
            nameTextView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8),
            nameTextView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.1)
        ])
        
        NSLayoutConstraint.activate([
            scientificNameTextView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            scientificNameTextView.topAnchor.constraint(equalTo: nameTextView.bottomAnchor, constant: 12),
            scientificNameTextView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8),
            scientificNameTextView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.1)
        ])
        
        NSLayoutConstraint.activate([
            lastWateredTextView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            lastWateredTextView.topAnchor.constraint(equalTo: scientificNameTextView.bottomAnchor, constant: 12),
            lastWateredTextView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8),
            lastWateredTextView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.05)
        ])

        NSLayoutConstraint.activate([
            saveButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            saveButton.topAnchor.constraint(equalTo: lastWateredTextView.bottomAnchor, constant: 300),
            saveButton.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.6),
            saveButton.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.05)
        ])
    }

}

protocol AddPlantDelegate: UIViewController {
    func addPlant(name: String, scientificName: String)
    
}
