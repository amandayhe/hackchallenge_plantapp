//
//  PlantCollectionViewCell.swift
//  midpoint
//
//  Created by Javier Villalpando on 11/28/22.
//

import UIKit

class PlantCollectionViewCell: UICollectionViewCell {
    
    var plantName = UILabel()
    
    override init(frame: CGRect){
        super.init(frame: frame)
        
        contentView.layer.cornerRadius = 6
        contentView.clipsToBounds = true
        contentView.backgroundColor = UIColor(red: 0.886, green: 0.761, blue: 0.722, alpha: 1)
        
        plantName.translatesAutoresizingMaskIntoConstraints = false
        plantName.textColor = UIColor(red: 0.98, green: 0.98, blue: 0.98, alpha: 1)
        contentView.addSubview(plantName)
        setupConstraints()
    }
    
    func setupConstraints(){
        NSLayoutConstraint.activate([
            plantName.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            plantName.centerXAnchor.constraint(equalTo: contentView.centerXAnchor)
        ])
    }
    
//    func configure(plant: Plant){
//        plantName.text = plant.plantName
//    }
    func configure(plantObject: PlantA){
        plantName.text = plantObject.name
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}
