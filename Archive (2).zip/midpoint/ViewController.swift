//
//  ViewController.swift
//  midpoint
//
//  Created by Javier Villalpando on 11/28/22.
//

import UIKit

class ViewController: UIViewController {

    var plantCollectionView: UICollectionView!
    
    var plantData: [PlantA] = []
    
    let spacing:CGFloat = 15
    let filterSpacing: CGFloat = 10
    
    let plantReuseIdentifier: String = "plantReuseIdentifier"
    
    let addPlantButton = UIBarButtonItem()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        addPlantButton.image = UIImage(systemName: "plus")
        addPlantButton.target = self
        addPlantButton.action = #selector(pushCreateView)
        navigationItem.rightBarButtonItem = addPlantButton
        
        
        view.backgroundColor = .white
        title = "My Plants"
        
        let plantlayout = UICollectionViewFlowLayout()
        plantlayout.minimumLineSpacing = spacing
        plantlayout.minimumInteritemSpacing = 10
        plantlayout.scrollDirection = .vertical
        
        // TODO: Instantiate collectionView
        plantCollectionView = UICollectionView(frame: .zero, collectionViewLayout: plantlayout)
        plantCollectionView.translatesAutoresizingMaskIntoConstraints = false
        plantCollectionView.register(PlantCollectionViewCell.self, forCellWithReuseIdentifier: plantReuseIdentifier)
        plantCollectionView.dataSource = self
        plantCollectionView .delegate = self
        view.addSubview(plantCollectionView)
        createDummyData()
        print(self.plantData)
        setupConstraints()
        
    }
    
    func createDummyData(){
        NetworkManager.getAllPlants{ plants in
            self.plantData = plants.plants
            self.plantCollectionView.reloadData()
            
        }
    }
    
    func setupConstraints() {
        let collectionViewPadding: CGFloat = 10
        NSLayoutConstraint.activate([
            plantCollectionView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: collectionViewPadding),
            plantCollectionView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor,constant: -collectionViewPadding),
            plantCollectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor,constant: collectionViewPadding),
            plantCollectionView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor,constant: -collectionViewPadding)
        ])
        
    }
    @objc func pushCreateView() {
        navigationController?.pushViewController(AddPlantViewController(delegate: self), animated: true)
    }


}

extension ViewController: AddPlantDelegate {
    func addPlant(name: String, scientificName: String) {
        NetworkManager.createPlant(name: name, scientific_name: scientificName, last_watered: 0, notes: ""){
            plant in
            self.plantData = self.plantData + [plant]
            self.plantCollectionView.reloadData()
        }
    }
}

extension ViewController: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return plantData.count
        
        
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: plantReuseIdentifier, for: indexPath) as! PlantCollectionViewCell
        let plantObject = plantData[indexPath.row]
        cell.configure(plantObject: plantObject)
        return cell
    }
}

extension ViewController: UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = plantCollectionView.cellForItem(at: indexPath)as! PlantCollectionViewCell
        present(PlantViewController(plant: plantData[indexPath.row]), animated: true)
    }
}

extension ViewController: UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (collectionView.frame.width - 20) / 2.0
        let height = (collectionView.frame.width - 10) / 2.0
        return CGSize(width: width, height: height)
    }
}

