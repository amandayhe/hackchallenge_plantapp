//
//  NetworkManager.swift
//  midpoint
//
//  Created by Javier Villalpando on 12/1/22.
//

import Alamofire
import Foundation

class NetworkManager{
    static let host = "http://35.186.167.103/"
    
    static func getAllPlants(completion: @escaping (PlantAResponse) -> Void){
        let endpoint = "\(host)/api/plants"
        AF.request(endpoint, method: .get).validate().responseData{
            response in
            switch response.result{
            case .success(let plants):
                let jsonDecoder = JSONDecoder()
                if let userResponse = try?
                    jsonDecoder.decode(PlantAResponse.self, from: plants){
                    completion(userResponse)
                }else{
                    print("Failed to decode getAllPlants")
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
        
    }
    
    static func createPlant(name: String, scientific_name: String, last_watered: Int?, notes: String?, completion: @escaping (PlantA)-> Void){
        let endpoint = "\(host)/api/plants"
        
        let params: Parameters = [
            "name": name,
            "scientific_name": scientific_name,
            "last_watered": last_watered!,
            "notes": notes!
        ]
        
        AF.request(endpoint, method: .post, parameters: params,
                   encoding: JSONEncoding.default).responseData{
            response in
            switch response.result{
            case .success(let plants):
                let jsonDecoder = JSONDecoder()
                if let userResponse = try?
                    jsonDecoder.decode(PlantA.self, from: plants){
                    completion(userResponse)
                }else{
                    print("Failed to decode createPlant")
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    static func deletePlant(id: Int, completion: @escaping (PlantA) -> Void){
        let endpoint = "\(host)/api/plants/\(id)"
        
        AF.request(endpoint, method: .delete).responseData {
            response in
            switch response.result{
            case .success(let plants):
                let jsonDecoder = JSONDecoder()
                if let userResponse = try?
                    jsonDecoder.decode(PlantA.self, from: plants){
                    completion(userResponse)
                }else{
                    print("Failed to decode deleteTicket")
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
}
