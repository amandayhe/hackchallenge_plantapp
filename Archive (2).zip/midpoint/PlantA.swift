//
//  PlantA.swift
//  midpoint
//
//  Created by Javier Villalpando on 12/1/22.
//

import Foundation

struct PlantA: Codable{
    let id: Int
    var name: String
    var scientific_name: String
    var last_watered: String
    var notes: String
    var tags: [String]
    
    enum CodingKeys: String, CodingKey{
        case id
        case name
        case scientific_name
        case last_watered
        case notes
        case tags
    }
}

struct PlantAResponse: Codable{
    let plants: [PlantA]
}
