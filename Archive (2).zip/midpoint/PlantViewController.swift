//
//  PlantViewController.swift
//  midpoint
//
//  Created by Javier Villalpando on 11/29/22.
//

import UIKit


class PlantViewController: UIViewController {


    
    var plantTextLabel = UILabel()
    var plantLabel = UILabel()
    var noteLabel = UILabel()
    var infoLabel = UILabel()
    
//    let plant: Plant
    let plant: PlantA


    init(plant: PlantA){
        self.plant = plant
        super.init(nibName: nil, bundle: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .white
//        plantNotes = plant.notes
        // Do any additional setup after loading the view.
        
        plantTextLabel.text = plant.name
        plantTextLabel.translatesAutoresizingMaskIntoConstraints = false
        plantTextLabel.textColor = UIColor(red: 0.149, green: 0.337, blue: 0.204, alpha: 1)
        view.addSubview(plantTextLabel)
        
        plantLabel.translatesAutoresizingMaskIntoConstraints = false
        plantLabel.layer.cornerRadius = 6
        plantLabel.textAlignment = .center
        plantLabel.text = plant.name
        plantLabel.textColor = .white
        plantLabel.layer.masksToBounds = true 
        plantLabel.backgroundColor = UIColor(red: 0.888, green: 0.761, blue: 0.721, alpha: 1)
        view.addSubview(plantLabel)
        
        infoLabel.translatesAutoresizingMaskIntoConstraints = false
        infoLabel.text = "Scientific Name: " + plant.scientific_name
        infoLabel.layer.cornerRadius = 6
        infoLabel.layer.masksToBounds = true
        infoLabel.textColor = .white
        infoLabel.textAlignment = .center
        infoLabel.backgroundColor = UIColor(red: 0.149, green: 0.149, blue: 0.149, alpha: 0.75)
        view.addSubview(infoLabel)
        
        
        noteLabel.translatesAutoresizingMaskIntoConstraints = false
        noteLabel.layer.cornerRadius = 8
        noteLabel.layer.masksToBounds = true
        noteLabel.text = plant.notes
        noteLabel.textAlignment = .center
        noteLabel.backgroundColor = UIColor(red: 0.659, green: 0.659, blue: 0.659, alpha: 0.5)
        noteLabel.textColor = .white
        view.addSubview(noteLabel)
        
        
        
        
        
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            plantTextLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor,constant: 25),
            plantTextLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            plantTextLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 50),
            plantLabel.heightAnchor.constraint(equalToConstant: 200),
            plantLabel.widthAnchor.constraint(equalToConstant: 300),
            plantLabel.topAnchor.constraint(equalTo: plantTextLabel.bottomAnchor,constant: 15),
            plantLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor,constant: 40),
            infoLabel.topAnchor.constraint(equalTo: plantLabel.bottomAnchor,constant: 15),
            infoLabel.leadingAnchor.constraint(equalTo: plantLabel.leadingAnchor),
            infoLabel.heightAnchor.constraint(equalToConstant: 150),
            infoLabel.widthAnchor.constraint(equalToConstant: 300),
            noteLabel.topAnchor.constraint(equalTo: infoLabel.bottomAnchor,constant: 15),
            noteLabel.leadingAnchor.constraint(equalTo: infoLabel.leadingAnchor),
            noteLabel.heightAnchor.constraint(equalToConstant: 300),
            noteLabel.widthAnchor.constraint(equalToConstant: 300)
        ])
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }


}


